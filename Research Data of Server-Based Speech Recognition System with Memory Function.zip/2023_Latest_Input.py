import os
import pyaudio
import wave

# 设置录音参数
CHUNK = 1024  # 音频块的大小
FORMAT = pyaudio.paInt16  # 采样位数
CHANNELS = 1  # 声道数
RATE = 44100  # 采样率（每秒的样本数）
RECORD_SECONDS = 20  # 录音时长（秒）
OUTPUT_DIR = "C:\\Users\\dear玺\\Desktop\\spin"  # 输出目录
BACKUP_DIR = "C:\\Users\\dear玺\\Desktop\\spin_1"  # 备份目录

# 创建 PyAudio 对象
audio = pyaudio.PyAudio()

# 打开麦克风进行录音
stream = audio.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)

print("开始录音...")

# 创建一个空的音频帧列表
frames = []

try:
    # 持续录音直到录制时长结束
    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        # 从麦克风读取音频数据
        data = stream.read(CHUNK)
        frames.append(data)

    print("录音结束...")

    # 停止录音流
    stream.stop_stream()
    stream.close()
    audio.terminate()

    # 将音频帧合并为完整的音频数据
    audio_data = b''.join(frames)

    # 创建输出目录（如果不存在）
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 创建备份目录（如果不存在）
    os.makedirs(BACKUP_DIR, exist_ok=True)

    # 设置输出文件名
    output_file = os.path.join(OUTPUT_DIR, "record.wav")

    # 检查是否已经存在同名文件
    if os.path.exists(output_file):
        # 如果有重复文件，将其移动到备份目录中并重命名为"record_1.wav"，"record_2.wav"等
        file_num = 1
        while True:
            backup_file = os.path.join(BACKUP_DIR, f"record_{file_num}.wav")
            if not os.path.exists(backup_file):
                os.rename(output_file, backup_file)
                break
            file_num += 1

    # 将音频数据保存为 WAV 文件
    with wave.open(output_file, 'wb') as wav_file:
        wav_file.setnchannels(CHANNELS)
        wav_file.setsampwidth(audio.get_sample_size(FORMAT))
        wav_file.setframerate(RATE)
        wav_file.writeframes(audio_data)

    print("录音已保存为 WAV 文件：", output_file)

except KeyboardInterrupt:
    print("停止录音...")

    # 停止录音流
    stream.stop_stream()
    stream.close()
    audio.terminate()
