import os
import shutil
import speech_recognition as sr

# 创建语音识别器对象
r = sr.Recognizer()

# 设置目录路径
INPUT_DIR = "C:\\Users\\dear玺\\Desktop\\spin"  # 输入目录
OUTPUT_DIR = "C:\\Users\\dear玺\\Desktop\\word"  # 输出目录
BACKUP_DIR = OUTPUT_DIR + "_1"  # 备份目录

def recognize_audio_file(audio_file):
    with sr.AudioFile(audio_file) as source:
        # 从音频文件中加载音频数据
        audio = r.record(source)

        try:
            # 将音频转换为文本
            text = r.recognize_google(audio, language="zh-CN")  # 使用Google的语音识别服务
            return text

        except sr.UnknownValueError:
            print(f"无法识别音频文件 {audio_file}")
            return None
        except sr.RequestError as e:
            print(f"无法连接到Google的语音识别服务： {e}")
            return None

# 创建备份目录（如果不存在）
os.makedirs(BACKUP_DIR, exist_ok=True)

# 移动已存在的文件到备份目录中
def move_existing_files():
    existing_files = os.listdir(OUTPUT_DIR)
    for existing_file in existing_files:
        existing_file_path = os.path.join(OUTPUT_DIR, existing_file)
        new_file_path = os.path.join(BACKUP_DIR, generate_unique_filename(existing_file))
        shutil.move(existing_file_path, new_file_path)
        print(f"已将已存在的文件移动到：{new_file_path}")

def generate_unique_filename(file_name):
    base_name, ext = os.path.splitext(file_name)
    counter = 1
    new_file_name = file_name
    while os.path.exists(os.path.join(BACKUP_DIR, new_file_name)):
        new_file_name = f"{base_name}_{counter}{ext}"
        counter += 1
    return new_file_name

move_existing_files()

# 获取输入目录中的文件列表
input_files = os.listdir(INPUT_DIR)
for file_name in input_files:
    if file_name.lower().endswith(".wav"):
        input_file_path = os.path.join(INPUT_DIR, file_name)
        recognized_text = recognize_audio_file(input_file_path)

        if recognized_text is not None:
            # 创建输出目录（如果不存在）
            os.makedirs(OUTPUT_DIR, exist_ok=True)

            # 设置输出文件名
            output_file_name = f"{os.path.splitext(file_name)[0]}.txt"
            output_file_path = os.path.join(OUTPUT_DIR, output_file_name)

            # 写入识别的文本到输出文件
            with open(output_file_path, "w", encoding="utf-8") as output_file:
                output_file.write(recognized_text)

            print("语音识别结果已保存到：", output_file_path)
