import os
import time
import logging
import socket
import threading

# 配置日志记录
logging.basicConfig(filename='file_changes.log', level=logging.INFO,
                    format='%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')


# 获取本机IP地址
def get_local_ip():
    try:
        host_name = socket.gethostname()
        local_ip = socket.gethostbyname(host_name)
        return local_ip
    except socket.error:
        return "Unable to get IP address"


# 监控文件夹
def monitor_folder(folder_path):
    try:
        # 初始化文件字典，保存文件的初始状态
        initial_files = {file: None for file in os.listdir(folder_path)}

        while True:
            # 获取当前文件列表
            current_files = os.listdir(folder_path)

            # 检查新增的文件或修改的文件
            for file in current_files:
                if file not in initial_files or initial_files[file] != os.path.getmtime(
                        os.path.join(folder_path, file)):
                    # 记录文件改变日志
                    logging.info(f"File '{file}' has been changed in {folder_path}")
                    # 更新文件的最新修改时间
                    initial_files[file] = os.path.getmtime(os.path.join(folder_path, file))

            # 检查被删除的文件
            for file in list(initial_files):
                if file not in current_files:
                    # 记录文件删除日志
                    logging.info(f"File '{file}' has been deleted from {folder_path}")
                    # 移除已删除的文件
                    del initial_files[file]

            time.sleep(1)  # 休眠1秒后再次检查文件变动
    except KeyboardInterrupt:
        print("Monitoring stopped.")


if __name__ == '__main__':
    folder_path = r"C:\PythonScripts"
    local_ip = get_local_ip()
    print(f"Monitoring folder: {folder_path}")
    print(f"Local IP Address: {local_ip}")

    # 在后台线程中运行监控函数
    monitor_thread = threading.Thread(target=monitor_folder, args=(folder_path,))
    monitor_thread.daemon = True  # 设置为守护线程，确保程序退出时线程自动终止
    monitor_thread.start()

    # 让主线程等待
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Monitoring stopped.")
