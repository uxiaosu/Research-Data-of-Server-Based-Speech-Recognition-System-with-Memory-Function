import subprocess

# Define the paths for the two scripts
script1_path = "C:\\Users\\dear玺\\PycharmProjects\\navf ai\\语音识别系统\\2023_最新录入.py"
script2_path = "C:\\Users\\dear玺\\PycharmProjects\\navf ai\\语音识别系统\\2023_最新输出.py"

# Execute the first script (2023_最新录入.py)
subprocess.run(["python", script1_path])

# Execute the second script (2023_最新输出.py)
subprocess.run(["python", script2_path])
